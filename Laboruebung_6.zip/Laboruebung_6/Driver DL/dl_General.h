/*
 * dl_General.h
 *
 *  Created on: 21.10.2025
 *      Author: danie
 */

#ifndef DRIVER_DL_DL_GENERAL_H_
#define DRIVER_DL_DL_GENERAL_H_

#include "dl_Aktoren.h"

void dl_Init();

#endif /* DRIVER_DL_DL_GENERAL_H_ */
