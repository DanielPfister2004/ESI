/*
 * dl_LCD.h
 *
 *  Created on: 17.11.2025
 *      Author: danie
 */

#ifndef DRIVER_DL_DL_LCD_H_
#define DRIVER_DL_DL_LCD_H_

#include "msp430.h"
//#include "dl_fronttable.h"

#define LCD_MAX_COLM 128

#define SET_PAGE 0xB0
#define LAST_PAGE 0xB7

#define MSB_COL_ADDR 0x10
#define LSB_COL_ADDR 0x00

#define LCD_RESET         0xE2
#define LCD_BIAS          0xA3
#define ADC_SEL_NORMAL    0xA0
#define COMMON_REVERSE    0xC8
#define RES_RATIO         0x24
#define ELEC_VOL_MODE     0x81
#define ELEC_VOL_VALUE    0x0F
#define POWER_CONT        0x2F
#define DISPLAY_ON        0xAF

#define LCD_DATA    (P8OUT = (P8OUT | LCD_DATACMD))     // A0 = 1 - Datenmodus
#define LCD_COMMAND (P8OUT = (P8OUT & ~LCD_DATACMD))    // A0 = 0 - Kommandomodus

#define LCD_RESET_PIN BIT0
#define LCD_RESET_LOW  (P9OUT &~ LCD_RESET_PIN)
#define LCD_RESET_HIGH (P9OUT |= LCD_RESET_PIN)

void dl_LCDWriteCommand(unsigned char *data , unsigned char data_length);
void dl_LCDInit();
void dl_LCDClear();
void dl_LCD_SetPosition(unsigned char page_sel, unsigned char col_sel);
void dl_LCDWriteText(char *text , unsigned char text_length , unsigned char page , unsigned char col);
void LCD_pixal_text();

#endif /* DRIVER_DL_DL_LCD_H_ */
