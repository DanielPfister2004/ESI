/*
 * hal_timerA1.h
 *
 *  Created on: 21.10.2025
 *      Author: danie
 */

#ifndef HARDWARE_HAL_HAL_TIMERA1_H_
#define HARDWARE_HAL_HAL_TIMERA1_H_


void hal_timerA1_Init();


#endif /* HARDWARE_HAL_HAL_TIMERA1_H_ */
