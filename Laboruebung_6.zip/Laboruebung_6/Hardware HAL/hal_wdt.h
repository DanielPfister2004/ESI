/*
 * hal_wdt.h
 *
 *  Created on: 30.09.2025
 *      Author: danie
 */

#ifndef HARDWARE_HAL_HAL_WDT_H_
#define HARDWARE_HAL_HAL_WDT_H_

void hal_WdtInit();

#endif /* HARDWARE_HAL_HAL_WDT_H_ */
