/*
 * hal_general.h
 *
 *  Created on: 30.09.2025
 *      Author: danie
 */

#ifndef HARDWARE_HAL_HAL_GENERAL_H_
#define HARDWARE_HAL_HAL_GENERAL_H_


void hal_init();
void HAL_PMM_Init();


void enableInterrupts();

#endif /* HARDWARE_HAL_HAL_GENERAL_H_ */


