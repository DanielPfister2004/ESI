/*
 * hal_LCD.h
 *
 *  Created on: 12.11.2025
 *      Author: danie
 */

#ifndef HARDWARE_HAL_HAL_LCD_H_
#define HARDWARE_HAL_HAL_LCD_H_

#include <msp430.h>
#include "hal_gpio.h"

void LCD_BL_ON();
void LCD_BL_OFF();

#endif /* HARDWARE_HAL_HAL_LCD_H_ */
