#include "dl_LCD.h"
#include "Hardware HAL/hal_LCD.h"
#include "dl_fronttable.h"
#include "Hardware HAL/hal_usciB1.h"

extern USCIB1_SPICom LCD;  // globale Instanz

void dl_LCDInit()
{
    LCD_BL_ON();
    LCD_RESET_LOW;

    __delay_cycles(500000);
    __delay_cycles(500000);
    LCD_RESET_HIGH;

    unsigned char init_seq[9] = {
    LCD_RESET,
                                  LCD_BIAS, ADC_SEL_NORMAL, COMMON_REVERSE,
                                  RES_RATIO,
                                  ELEC_VOL_MODE, ELEC_VOL_VALUE, POWER_CONT,
                                  DISPLAY_ON };
    dl_LCDWriteCommand(init_seq, sizeof(init_seq));

    //LCD_pixal_text();

    dl_LCDClear();
}

void LCD_pixal_text()
{
    __delay_cycles(50000000);
    unsigned char all_point_on[2] = { 0xA5, 0xA4 };

    dl_LCDWriteCommand(&all_point_on[0], 1);
    __delay_cycles(50000000);
    dl_LCDWriteCommand(&all_point_on[1], 1);
    __delay_cycles(50000000);
}

void dl_LCDWriteCommand(unsigned char *data, unsigned char data_length)
{
    unsigned char i;
    while (LCD.Status.TxSuc == 0)
        ;
    LCD_COMMAND;

    for (i = 0; i < data_length; i++)
    {
        LCD.TxData.Data[i] = *data;
        data++;
    }

    LCD.TxData.len = data_length;
    LCD.TxData.cnt = 0;
    hal_USCIB1Transmit();
    while (LCD.Status.TxSuc == 0)
        ;
}

void dl_LCDSetPosition(unsigned char page, unsigned char col)
{
    unsigned char cmd[3];
    cmd[0] = 0xB0 | (page & 0x0F);                 // Page address
    cmd[1] = 0x10 | ((col >> 4) & 0x0F);           // Column address MSN
    cmd[2] = 0x00 | (col & 0x0F);                  // Column address LSN

    dl_LCDWriteCommand(cmd, 3);
}

void dl_LCDClear(void)
{
    unsigned char i, j;

    for (j = 0; j < 8; j++)
    {
        dl_LCDSetPosition(j, 0);

        for (i = 0; i < LCD_MAX_COLM; i++)
            LCD.TxData.Data[i] = 0x00;

        LCD.TxData.len = LCD_MAX_COLM;

        LCD_DATA;
        hal_USCIB1Transmit();

        while (!LCD.Status.TxSuc)
            ;
    }
}

void dl_LCDWriteText(char *text, unsigned char text_length, unsigned char page,
                     unsigned char col)
{
    // max page            ...  8
    // max symbol per page ... 20
    unsigned char text_length_cnt;
    unsigned char i, col_pos = col;
    LCD.TxData.len = text_length;

    // Dislay Cursor setzen
    dl_LCDSetPosition(page, col * fonts_width_max);
    // Wait for Display
    while (UCB1STAT & UCBUSY)
        ;
    // Auf Datenmodus wechseln
    LCD_DATA;

    for (text_length_cnt = 0; text_length_cnt < text_length; text_length_cnt++)
    // Textl�nge des Strings abarbeiten
    {
        for (i = 0; i < fonts_width_max; i++)
        {
            LCD.TxData.Data[i] = font_table[*text][i];
            col_pos++;
        }

        LCD.TxData.len = fonts_width_max;
        hal_USCIB1Transmit();

        // Daten an das Display senden // Warten bis �bertragung fertig ist
        while (!LCD.Status.TxSuc)
            ;

        // Column �overflow�?
        // Einf�gen einer Abfrage ob das Ende der Page erreicht ist
        if (col_pos + fonts_width_max > LCD_MAX_COLM)
            break; // oder page++ wenn n�chste zeile

        text++;
    }
}

void test_message()
{
    dl_LCDWriteText("A", 1, 1, 0);
    dl_LCDWriteText("B", 1, 1, 20);
    dl_LCDWriteText("Ich halt es nicht", 17, 3, 0);
    dl_LCDWriteText("mehr aus", 8, 4, 0);
    dl_LCDWriteText("67", 2, 6, 9);
}
