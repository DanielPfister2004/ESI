################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Driver\ DL/dl_Aktoren.c \
../Driver\ DL/dl_General.c \
../Driver\ DL/dl_LCD.c 

C_DEPS += \
./Driver\ DL/dl_Aktoren.d \
./Driver\ DL/dl_General.d \
./Driver\ DL/dl_LCD.d 

OBJS += \
./Driver\ DL/dl_Aktoren.obj \
./Driver\ DL/dl_General.obj \
./Driver\ DL/dl_LCD.obj 

OBJS__QUOTED += \
"Driver DL\dl_Aktoren.obj" \
"Driver DL\dl_General.obj" \
"Driver DL\dl_LCD.obj" 

C_DEPS__QUOTED += \
"Driver DL\dl_Aktoren.d" \
"Driver DL\dl_General.d" \
"Driver DL\dl_LCD.d" 

C_SRCS__QUOTED += \
"../Driver DL/dl_Aktoren.c" \
"../Driver DL/dl_General.c" \
"../Driver DL/dl_LCD.c" 


