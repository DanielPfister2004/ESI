# FIXED

Hardware\ HAL/hal_wdt.obj: ../Hardware\ HAL/hal_wdt.c
Hardware\ HAL/hal_wdt.obj: ../Hardware\ HAL/hal_wdt.h
Hardware\ HAL/hal_wdt.obj: C:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430.h
Hardware\ HAL/hal_wdt.obj: C:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430f5335.h
Hardware\ HAL/hal_wdt.obj: C:/ti/ccs1281/ccs/ccs_base/msp430/include/in430.h
Hardware\ HAL/hal_wdt.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h
Hardware\ HAL/hal_wdt.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h

../Hardware\ HAL/hal_wdt.c:

../Hardware\ HAL/hal_wdt.h:

C:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430.h:

C:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430f5335.h:

C:/ti/ccs1281/ccs/ccs_base/msp430/include/in430.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h:

