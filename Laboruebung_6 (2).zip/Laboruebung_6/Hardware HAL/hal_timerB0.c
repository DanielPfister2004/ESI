/*
 * timerB0.c
 *
 *  Created on: 12.11.2025
 *      Author: danie
 */
#include "hal_timerB0.h"
#include "hal_usciB1.h"
#include "hal_LCD.h"

extern USCIB1_SPICom LCD;
volatile static int internal_cnt = 0;

// is a 2Hz timer
void timerB0_init()
{
    TB0CTL |= TBSSEL__SMCLK;
    TB0CTL |= ID__8;
    TB0CTL |= MC__UP;

    TB0CCR0 = 19531 / 2; // 2.5MHz/(8*8) * 0,5 (sind die 2Hz)
    TB0EX0 |= TBIDEX__8;  // extension
    TB0CCTL0 = CCIE;  // activating interrupt
    LCD.Status.TxSuc = 1;
}

void switching_BL()
{
    int cnt = 0;
    if (cnt == 0)
    {
        cnt = 1;
        LCD_BL_ON();
    }
    else if (cnt == 1)
    {
        cnt = 0;
        LCD_BL_OFF();
    }
}

void wait_one_sec()
{
    int start = internal_cnt;
    while ((internal_cnt - start) < 4)
        ;
}

void wait_seconds(int sec)
{
    internal_cnt = 0;
    while (internal_cnt < 4 * sec)
        ;
}

int wait_seconds_elapsed(int sec)
{
    static unsigned int start = 0;             // persistenter Startwert
    unsigned int ticks_needed = 4 * sec;       // 2 ISR-Ticks pro Sekunde
    unsigned int now = internal_cnt;           // aktueller Z�hler

    // Overflow korrekt behandeln
    if (now < start)  // unsigned overflow
        start = now;

    if ((now - start) >= ticks_needed)
    {
        start = now;  // Reset f�r n�chsten Zeitraum
        return 1;     // Zeit ist abgelaufen
    }
    else
        return 0;     // noch nicht abgelaufen

}

#pragma vector=TIMER0_B0_VECTOR
__interrupt void TimerB0_ISR(void)
{
// switching_BL();
    internal_cnt++;

    TB0CCTL0 &= ~CCIFG;   // Clear interrupt flag
}

