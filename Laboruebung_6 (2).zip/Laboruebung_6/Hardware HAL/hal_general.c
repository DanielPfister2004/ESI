#include "hal_general.h"
#include "hal_pmm.h"
#include "hal_wdt.h"
#include "hal_gpio.h"
#include "hal_ucs.h"
#include "hal_timerA1.h"
#include "hal_usciB1.h"
#include "hal_LCD.h"
#include "hal_timerB0.h"
#include "hal_timerA0.h"

extern int one_hz_cnt;
extern USCIB1_SPICom LCD;
extern int activate_motor;

void hal_init()
{
    hal_WdtInit();
    HAL_PMM_Init();
    hal_GpioInit();
    hal_ucsInit();

    timerB0_init();         // 2Hz timer
    init_GPIO_SPI();
    hal_USCIB1Init();

    if(activate_motor)
    {
        hal_timerA0_rpm_measurements_init();
        hal_timerA1_Init();   // throttle and sterring
    }


    __enable_interrupt();
}



// enable Interrupt for START_BUTTON PORT1 BIT6
void enableInterrupts()
{
    P1DIR &= ~(START_BUTTON + STOP_BUTTON);
    P1REN |= (START_BUTTON+ STOP_BUTTON);
    P1OUT |= (START_BUTTON+ STOP_BUTTON);
    P1IE |= (START_BUTTON+ STOP_BUTTON);
    P1IES &= ~(START_BUTTON + STOP_BUTTON);      //rising edge
    //P1IES |= (START_BUTTON + STOP_BUTTON);       //falling edge
    P1IFG &= ~(START_BUTTON + STOP_BUTTON);      // erasing Interrupt-flag - if not deleted, ...
                                 // ...there will be an interrupt right after the car is booted up

    __enable_interrupt(); // GIE ... global interrupt enable
}



